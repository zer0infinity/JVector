#!/bin/bash
java -jar JVector.jar
